Juku replica release evidence snapshot
Decision: DESIGN HOLD
This archive is for review. It is not the Gerber/drill upload ZIP.
Read docs/replica-release-evidence-package.md first.
